<?php
    session_start();
    echo "Welcome ".$_SESSION["user"].", <a href ='logout.php'>Logout</a>";
?>