<html>
<head>
	<title>Sign In</title>
</head>
<body>
	<form action="login_try.php" method="post">
		<table align="center">
			<th colspan="2">Login</th>
			<tr>
				<td>
					User Name
				</td>
				<td>
					<input type="text" name="txtUser" required>
				</td>
			</tr>
			<tr>
				<td>
					Password
				</td>
				<td>
					<input type="password" name="txtPass" required>
				</td>
			</tr>
            <tr>
				<td colspan="2" align="right">
					<input type="submit" value="Login">
				</td>
			</tr>
            <tr>
				<td colspan="2">
					<?php
						if (isset($_GET["Message"])) {
							echo $_GET["Message"];
						}
					?>
				</td>
			</tr>
		</table>
	</form>
</body>
</html>