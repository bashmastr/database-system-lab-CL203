<?php
    include "connect.php";
    session_start();

    $user = $_POST["txtUser"];
    $pass = $_POST["txtPass"];
    
    $qry = "SELECT * FROM users WHERE user_name = '".$user."'";
    //echo $qry;
    $res = $con->query($qry);

    $msg = "";
    if($res->num_rows > 0)
    {
        //user exists
        $row = $res->fetch_assoc();
        if($row["password"] == $pass)
        {
            $_SESSION["user"] = $user;
            $_SESSION["type"] = $row["type"];
            
            if($row["type"] == "academic")
                header("Location:register.php");
            else
                header("Location:st_home.php");
        }
        else
        {            
            $msg = "Invalid password";
            header("Location:login.php?Message=$msg");
        }
    }
    else
    {
        $msg = "The Username: ".$user." does not exist!";
        header("Location:login.php?Message=$msg");
    }
?>