<?php
	include "connect.php";
?>

<!DOCTYPE html>
<html>
<head>
	<title>Student's Record</title>
    <link href="css/bootstrap.min.css" rel="stylesheet" media="all">

    <style>
        .tblh{
            background: #616060;
            font-size: 14px;
            color: white;
        }
        .tblro{
            font-size: 12px;
        }
        .tblre{
            font-size: 12px;
            background: #E9E8E8;
        }
    </style>
</head>
<body>
	<form action="" method="post">
		<div class="Page-header mb-5" align="center">
            <h2>Student's Information</h2>
        </div>
        <div class="form-group row">
            <div class="col-sm-4"></div>
            <div class="col-sm-1">Search Type</div>
            <div class="col-sm-3">
                <select name="sType" class="form-control">
                    <option value="rollno">Roll No</option>
                    <option value="name">Name</option>
                </select>
            </div>
            <div class="col-sm-4"></div>
        </div>
        <div class="form-group row">
            <div class="col-sm-5"></div>
            <div class="col-sm-3">
                <input type="text" name="txtSrch" placeholder="Roll No/Name" class="form-control" required>
            </div>
            <div class="col-sm-4"></div>
        </div>
        <div class="form-group row">
            <div class="col-sm-4"></div>
            <div class="col-sm-4" align="right">
                <input type="submit" value="Search" class="btn btn-primary btn-block">
            </div>
            <div class="col-sm-4"></div>
        </div>      
        			
					
	</form>
	<?php
		if (isset($_POST["txtSrch"])) {
			$Srch = $_POST["txtSrch"];
            $type = $_POST["sType"];
            
            //echo $type;
            
            $qry = "";
            if($type == "rollno")
                $qry = "SELECT * FROM student WHERE roll_no = '".$Srch."'";
            elseif($type =="name")
                $qry = "SELECT * FROM student WHERE st_name LIKE '%".$Srch."%'";
            $res = $con->query($qry);
			$result = "";
            $class = "tblro";
            $flag = 1;

			if ($res->num_rows>0) {
                $result .= "<div class ='container'>";
				$result .= "<table align='center' class='table table-bordered'>";
				$result .= "<tr class='tblh'><th>Roll No</th><th>Name</th><th>Father's Name</th><th>Gender</th><th>Contact No</th><th>Address</th></tr>";
				while ($row = $res->fetch_assoc()) 
				{
					//one row
					$result .= "<tr class ='".$class."'>
									<td>
										".$row['roll_no']."
									</td>
									<td>
										".$row['st_name']."
									</td>
									<td>
										".$row['f_name']."
									</td>
									<td>
										".$row['gender']."
									</td>
									<td>
										".$row['contact']."
									</td>
									<td>
										".$row['address']."
									</td>
								</tr>";
                    
                    $flag++;
                    
                    if(($flag)%2==0)
                        $class = "tblre";
                    else
                        $class = "tblro";
				}
				$result .= "</table></div>";
			}
			echo $result;
		}
	?>
</body>
</html>