<?php 
	include "connect.php";
 ?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="courses_enter_try.php " align = center method="post">
  course Code
  <input type="text" name="c_code" ><br>
  course Name:
  <input type="text" name="c_name" ><br><br>
  <input type="submit" value="Add">
</form>
</body>
</html>